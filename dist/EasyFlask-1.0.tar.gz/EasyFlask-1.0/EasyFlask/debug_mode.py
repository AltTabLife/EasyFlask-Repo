#This file builds the website in debug mode to be changed on the fly. To build out to another file, use the source_build module

from flask import Flask, render_template_string
from pathlib import Path

from .html_generator import HTMLGenerator

app = Flask(__name__)

@app.route('/')
def index():
    input_file = Path('splash_page.yaml')
    html_generator = HTMLGenerator(input_file)
    html_output = html_generator.generate_html()

    return render_template_string(html_output)

config_file = Path('splash_page.yaml')
page_generator = HTMLGenerator(config_file)
html_output = page_generator.generate_html()

print(html_output)