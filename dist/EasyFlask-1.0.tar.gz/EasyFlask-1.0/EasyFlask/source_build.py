#Purpose of this is meant to be building the config_file website in a separate directory labeled whatever is parsed out to be

#First thing's first. I need to be able to parse out routes from the yaml

#I'm fucking getting ahead of myself again. This will be made later. I need to get the package working to where i can import the parser as-is in my main website.